// class PaperBag, turunan dari Produk extends
public class PaperBag extends Produk {
    private String ukuran;
    private String material;

    public PaperBag(String namaProduk, String satuan, double harga, String ukuran, String material) {
        super(namaProduk, satuan, harga);
        this.ukuran = ukuran;
        this.material = material;
    }

    public PaperBag() {
    }

    public void setUkuran(String ukuran) {
        this.ukuran = ukuran;
    }

    public void setMaterial(String material) {
        this.material = material;
    }

    public String getUkuran() {
        return ukuran;
    }

    public String getMaterial() {
        return material;
    }

    public String deskripsi() {
        return getNamaProduk() + " ukuran " + ukuran + ", bahan " + material;
    }
}