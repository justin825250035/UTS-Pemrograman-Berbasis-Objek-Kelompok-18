import java.util.ArrayList;
import java.io.File;
import java.io.FileWriter;
import java.io.FileReader;
import java.io.BufferedReader;
import java.io.IOException;
import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.JTable;
import javax.swing.JFrame;
import javax.swing.BoxLayout;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.Color;
import java.awt.Font;
import java.awt.BorderLayout;

// class Nota, implements Cetak jadi wajib punya method struk()
public class Nota implements Cetak {
    private String noNota;
    private String tanggal;
    private ArrayList<ItemNota> listItem = new ArrayList<ItemNota>();
    private Pembeli pembeli;
    private Toko toko;

    public Nota(String noNota, String tanggal, Pembeli pembeli, Toko toko) {
        this.noNota = noNota;
        this.tanggal = tanggal;
        this.pembeli = pembeli;
        this.toko = toko;
    }

    public Nota() {
    }

    public void addItem(ItemNota item) {
        listItem.add(item);
    }

    public String getNoNota() {
        return noNota;
    }

    public String getTanggal() {
        return tanggal;
    }

    public ArrayList<ItemNota> getListItem() {
        return listItem;
    }

    // jumlahin semua subtotal jadi total belanja
    public double hitungTotal() {
        double total = 0;
        for (int i = 0; i < listItem.size(); i++) {
            total = total + listItem.get(i).getSubTotal();
        }
        return total;
    }

    // method struk, isinya 3 langkah:
    // 1. cetak teks biasa ke layar
    // 2. simpan teks itu ke file txt
    // 3. munculin jendela JFrame yang bentuknya kayak nota asli
    public void struk() {
        String teks = "";
        teks = teks + "==================================================\n";
        teks = teks + "                " + TOKO + "\n";
        teks = teks + ALAMAT + "\n";
        teks = teks + "==================================================\n";
        teks = teks + "Tuan     : " + pembeli.getNamaTuan() + "\n";
        teks = teks + "Toko     : " + pembeli.getNamaToko() + "\n";
        teks = teks + "NOTA No. : " + noNota + "\n";
        teks = teks + "Tanggal  : " + tanggal + "\n";
        teks = teks + "--------------------------------------------------\n";
        teks = teks + "BANYAKNYA\tNAMA BARANG\t\tJUMLAH\n";
        teks = teks + "--------------------------------------------------\n";

        for (int i = 0; i < listItem.size(); i++) {
            ItemNota item = listItem.get(i);
            teks = teks + item.getJumlah() + " " + item.getProduk().getSatuan()
                    + "\t\t" + item.getProduk().getNamaProduk()
                    + "\t\t" + (int) item.getSubTotal() + "\n";
        }

        teks = teks + "--------------------------------------------------\n";
        teks = teks + "Jumlah Rp. : " + (int) hitungTotal() + "\n";
        teks = teks + "==================================================\n";
        teks = teks + "Tanda Terima                          Hormat Kami,\n";

        System.out.println(teks);

        // simpan ke file txt, nama filenya pake nomor nota
        try {
            File file = new File("nota_" + noNota + ".txt");
            FileWriter tulis = new FileWriter(file);
            tulis.write(teks);
            tulis.close();
            System.out.println("Struk sudah disimpan ke file: " + file.getAbsolutePath());
        } catch (IOException e) {
            System.out.println("Gagal simpan file: " + e.getMessage());
        }

        // bikin jendela nota pake komponen swing biasa
        int lebar = 380; // dikecilin lagi, biar proporsinya lebih mirip nota fisik aslinya (sempit memanjang)

        JPanel panelUtama = new JPanel();
        panelUtama.setLayout(new BoxLayout(panelUtama, BoxLayout.Y_AXIS));
        panelUtama.setBackground(Color.WHITE);
        panelUtama.setBorder(new EmptyBorder(10, 10, 10, 10));

        JPanel panelTanggal = new JPanel(new BorderLayout());
        panelTanggal.setBackground(Color.WHITE);
        panelTanggal.setMaximumSize(new java.awt.Dimension(lebar, 20));
        panelTanggal.add(new JLabel(tanggal), BorderLayout.EAST);
        panelUtama.add(panelTanggal);

        JPanel panelNamaToko = new JPanel(new BorderLayout());
        panelNamaToko.setBackground(Color.WHITE);
        panelNamaToko.setMaximumSize(new java.awt.Dimension(lebar, 25));
        JLabel labelToko = new JLabel(TOKO, JLabel.CENTER);
        labelToko.setFont(new Font("Arial", Font.BOLD, 16));
        labelToko.setForeground(Color.BLUE);
        panelNamaToko.add(labelToko, BorderLayout.CENTER);
        panelUtama.add(panelNamaToko);

        JPanel panelAlamat = new JPanel(new BorderLayout());
        panelAlamat.setBackground(Color.WHITE);
        panelAlamat.setMaximumSize(new java.awt.Dimension(lebar, 40));
        JLabel labelAlamat = new JLabel("<html><div style='text-align:center;'>" + ALAMAT + "</div></html>", JLabel.CENTER);
        labelAlamat.setForeground(Color.BLUE);
        labelAlamat.setFont(new Font("Arial", Font.PLAIN, 11));
        panelAlamat.add(labelAlamat, BorderLayout.CENTER);
        panelUtama.add(panelAlamat);
        
    
        
        
        
        
    

        panelUtama.add(new JLabel(" "));

        JPanel panelTuan = new JPanel(new BorderLayout());
        panelTuan.setBackground(Color.WHITE);
        panelTuan.setMaximumSize(new java.awt.Dimension(lebar, 20));
        panelTuan.add(new JLabel("Tuan : " + pembeli.getNamaTuan()), BorderLayout.WEST);
        panelUtama.add(panelTuan);

        JPanel panelTokoPembeli = new JPanel(new BorderLayout());
        panelTokoPembeli.setBackground(Color.WHITE);
        panelTokoPembeli.setMaximumSize(new java.awt.Dimension(lebar, 20));
        panelTokoPembeli.add(new JLabel("Toko : " + pembeli.getNamaToko()), BorderLayout.WEST);
        panelUtama.add(panelTokoPembeli);

        JPanel panelNota = new JPanel(new BorderLayout());
        panelNota.setBackground(Color.WHITE);
        panelNota.setMaximumSize(new java.awt.Dimension(lebar, 20));
        panelNota.add(new JLabel("NOTA No. : " + noNota), BorderLayout.WEST);
        panelUtama.add(panelNota);

        // spasi lebih banyak di sini, biar jaraknya ke tabel kayak di foto aslinya
        panelUtama.add(new JLabel(" "));
        panelUtama.add(new JLabel(" "));

        String[] namaKolom = { "BANYAKNYA", "NAMA BARANG", "HARGA", "JUMLAH" };

        int jumlahBaris = listItem.size();
        if (jumlahBaris < 8) {
            jumlahBaris = 8;
        }
        String[][] dataTabel = new String[jumlahBaris][4];

        for (int i = 0; i < listItem.size(); i++) {
            ItemNota item = listItem.get(i);
            dataTabel[i][0] = item.getJumlah() + " " + item.getProduk().getSatuan();
            dataTabel[i][1] = item.getProduk().getNamaProduk();
            dataTabel[i][2] = "" + (int) item.getProduk().getHarga();
            dataTabel[i][3] = "" + (int) item.getSubTotal();
        }
        for (int i = listItem.size(); i < jumlahBaris; i++) {
            dataTabel[i][0] = "";
            dataTabel[i][1] = "";
            dataTabel[i][2] = "";
            dataTabel[i][3] = "";
        }

        DefaultTableModel model = new DefaultTableModel(dataTabel, namaKolom);
        JTable tabel = new JTable(model);
        tabel.setRowHeight(26); // baris dibikin agak lebih tinggi, biar makin mirip nota fisik
        tabel.setEnabled(false);

        // atur lebar tiap kolom manual, biar nggak dibagi rata otomatis
        tabel.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
        tabel.getColumnModel().getColumn(0).setPreferredWidth(95);  // banyaknya
        tabel.getColumnModel().getColumn(1).setPreferredWidth(140); // nama barang
        tabel.getColumnModel().getColumn(2).setPreferredWidth(65);  // harga
        tabel.getColumnModel().getColumn(3).setPreferredWidth(80);  // jumlah

        // header-nya dibikin font lebih kecil biar tulisan BANYAKNYA nggak kepotong
        tabel.getTableHeader().setFont(new Font("Arial", Font.PLAIN, 9));

        JPanel panelTabel = new JPanel(new BorderLayout());
        panelTabel.setMaximumSize(new java.awt.Dimension(lebar, 22 * jumlahBaris + 25));
        panelTabel.add(tabel.getTableHeader(), BorderLayout.NORTH);
        panelTabel.add(tabel, BorderLayout.CENTER);
        panelUtama.add(panelTabel);

        panelUtama.add(new JLabel(" "));

        JPanel panelBawah = new JPanel(new BorderLayout());
        panelBawah.setBackground(Color.WHITE);
        panelBawah.setMaximumSize(new java.awt.Dimension(lebar, 20));
        panelBawah.add(new JLabel("Tanda Terima"), BorderLayout.WEST);
        JLabel labelJumlah = new JLabel("Jumlah Rp. " + (int) hitungTotal());
        labelJumlah.setFont(new Font("Arial", Font.BOLD, 13));
        panelBawah.add(labelJumlah, BorderLayout.EAST);
        panelUtama.add(panelBawah);

                JPanel panelHormat = new JPanel(new BorderLayout());
        panelHormat.setBackground(Color.WHITE);
        panelHormat.setMaximumSize(new java.awt.Dimension(lebar, 80));
        JPanel panelHormatInner = new JPanel();
        panelHormatInner.setBackground(Color.WHITE);
        panelHormatInner.setLayout(new BoxLayout(panelHormatInner, BoxLayout.Y_AXIS));
        JLabel labelHormat = new JLabel("Hormat Kami,");
        labelHormat.setAlignmentX(JLabel.RIGHT_ALIGNMENT);
        panelHormatInner.add(labelHormat);
        panelHormatInner.add(new JLabel(" "));
        panelHormatInner.add(new JLabel(" "));
        panelHormatInner.add(new JLabel(" "));
        panelHormat.add(panelHormatInner, BorderLayout.EAST);
        panelUtama.add(panelHormat);

        JFrame jendela = new JFrame("NOTA");
        jendela.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        jendela.add(panelUtama);
        jendela.pack();
        jendela.setLocationRelativeTo(null);
        jendela.setVisible(true);
    }

    // baca ulang file nota_<noNota>.txt yang pernah disimpan,
    // isinya ditampilin lagi ke layar
    public void bacaNota(String nomorNota) {
        try {
            File file = new File("nota_" + nomorNota + ".txt");
            BufferedReader baca = new BufferedReader(new FileReader(file));

            System.out.println("=== ISI NOTA " + nomorNota + " ===");
            String baris = baca.readLine();
            while (baris != null) {
                System.out.println(baris);
                baris = baca.readLine();
            }
            baca.close();

        } catch (IOException e) {
            System.out.println("Nota dengan nomor " + nomorNota + " tidak ditemukan.");
        }
    }
}