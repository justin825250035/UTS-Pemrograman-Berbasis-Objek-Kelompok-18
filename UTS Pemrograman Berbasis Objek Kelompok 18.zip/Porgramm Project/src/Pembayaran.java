// class Pembayaran, nyimpen total bayar sama status bayarnya
public class Pembayaran {
    private double totalBayar;
    private String statusBayar;

    public Pembayaran(double totalBayar, String statusBayar) {
        this.totalBayar = totalBayar;
        this.statusBayar = statusBayar;
    }

    public Pembayaran() {
    }

    public double getTotalBayar() {
        return totalBayar;
    }

    public String getStatusBayar() {
        return statusBayar;
    }
}