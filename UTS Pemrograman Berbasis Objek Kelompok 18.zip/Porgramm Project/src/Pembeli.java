// class Pembeli, turunan dari Person extends, implements Login
public class Pembeli extends Person implements Login {
    private String namaTuan;
    private String namaToko;

    public Pembeli(String kode, String namaTuan, String namaToko) {
        super(kode, namaTuan);
        this.namaTuan = namaTuan;
        this.namaToko = namaToko;
    }

    public Pembeli() {
    }

    public void setNamaTuan(String namaTuan) {
        this.namaTuan = namaTuan;
    }

    public void setNamaToko(String namaToko) {
        this.namaToko = namaToko;
    }

    public String getNamaTuan() {
        return namaTuan;
    }

    public String getNamaToko() {
        return namaToko;
    }

    public void signUp() {
        System.out.println(namaTuan + " berhasil daftar");
    }

    public void signIn() {
        System.out.println(namaTuan + " berhasil login");
    }

    // isi method info() punya Person
    public String info() {
        return "Pembeli: " + namaTuan + ", belanja di " + namaToko;
    }
}