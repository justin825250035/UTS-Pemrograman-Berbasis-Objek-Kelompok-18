// class Produk, class induk buat PaperBag, Lanyard, KertasKado.
// abstract karena ada method deskripsi() yang belum ada isinya
public abstract class Produk {
    private String namaProduk;
    private String satuan;
    private double harga;

    public Produk(String namaProduk, String satuan, double harga) {
        this.namaProduk = namaProduk;
        this.satuan = satuan;
        this.harga = harga;
    }

    public Produk() {
    }

    public void setNamaProduk(String namaProduk) {
        this.namaProduk = namaProduk;
    }

    public void setSatuan(String satuan) {
        this.satuan = satuan;
    }

    public void setHarga(double harga) {
        this.harga = harga;
    }

    public String getNamaProduk() {
        return namaProduk;
    }

    public String getSatuan() {
        return satuan;
    }

    public double getHarga() {
        return harga;
    }

    // method abstrak, wajib diisi sama PaperBag, Lanyard, KertasKado
    public abstract String deskripsi();
}