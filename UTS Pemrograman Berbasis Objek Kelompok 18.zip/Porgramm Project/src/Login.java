// interface Login
public interface Login {
    void signUp();
    void signIn();
}