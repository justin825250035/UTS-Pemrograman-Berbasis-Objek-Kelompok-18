import java.util.Scanner;

// class Toko, turunan dari Person extends, implements Login
public class Toko extends Person implements Login {
    private String namaToko;
    private String alamat;
    private String noTelepon;
    private String kota;

    public Toko(String namaToko, String alamat, String noTelepon, String kota) {
        this.namaToko = namaToko;
        this.alamat = alamat;
        this.noTelepon = noTelepon;
        this.kota = kota;
    }

    public Toko() {
    }

    public void setNamaToko(String namaToko) {
        this.namaToko = namaToko;
    }

    public void setAlamat(String alamat) {
        this.alamat = alamat;
    }

    public void setNoTelepon(String noTelepon) {
        this.noTelepon = noTelepon;
    }

    public String getNamaToko() {
        return namaToko;
    }

    public String getAlamat() {
        return alamat;
    }

    public String getNoTelepon() {
        return noTelepon;
    }

    public void signUp() {
        System.out.println(namaToko + " berhasil daftar");
    }

    // dipake buat login admin: username otomatis nama toko,
    // passwordnya "admin123", salah 3 kali program berhenti
    public void signIn() {
        Scanner input = new Scanner(System.in);
        int percobaan = 0;

        System.out.println("=== LOGIN ADMIN ===");
        System.out.println("Username : " + namaToko);

        while (percobaan < 3) {
            System.out.print("Password : ");
            String pass = input.nextLine();

            if (pass.equals("admin123")) {
                System.out.println("Login berhasil");
                return;
            }
            percobaan++;
            System.out.println("Password salah");
        }

        System.out.println("Gagal login 3 kali, program berhenti");
        System.exit(0);
    }

    // isi method info() punya Person
    public String info() {
        return "Toko: " + namaToko + ", " + alamat;
    }
}