import java.util.Scanner;

// class Menu, buat ngatur pilihan menu si kasir/admin.
// satu Menu make satu Nota yang lagi dikerjain
public class Menu {
    private Nota nota;

    public Menu(Nota nota) {
        this.nota = nota;
    }

    public Menu() {
    }

    // nampilin pilihan menu ke layar
    public void tampilMenu() {
        System.out.println();
        System.out.println("=== MENU ===");
        System.out.println("1. Tambah Barang");
        System.out.println("2. Cetak Struk");
        System.out.println("3. Baca Nota Lama");
        System.out.println("4. Keluar");
        System.out.print("Pilih menu : ");
    }

    // ngejalanin aksi sesuai menu yang dipilih user
    public void pilihMenu(int pilihan) {
        Scanner input = new Scanner(System.in);

        if (pilihan == 1) {
            // daftar harga barang, sesuai turunan Produk masing masing
            System.out.println("1. Paper Bag   Rp 25.000 / lusin");
            System.out.println("2. Lanyard     Rp 2.000 / pcs");
            System.out.println("3. Kertas Kado Rp 2.500 / lembar");
            System.out.print("Pilih barang (1/2/3) : ");
            int pilihBarang = Integer.parseInt(input.nextLine());
            System.out.print("Jumlah               : ");
            int jumlah = Integer.parseInt(input.nextLine());

            // Produk diisi dari turunan yang sesuai polymorphism
            Produk produk = null;
            if (pilihBarang == 1) {
                produk = new PaperBag("Paper Bag", "lusin", 25000, "Standar", "Kraft");
            } else if (pilihBarang == 2) {
                produk = new Lanyard("Lanyard", "pcs", 2000, "Standar", "Plastik");
            } else if (pilihBarang == 3) {
                produk = new KertasKado("Kertas Kado", "lembar", 2500, "Standar", "Standar");
            }

            if (produk != null) {
                nota.addItem(new ItemNota(produk, jumlah));
                System.out.println("Barang ditambahkan: " + produk.deskripsi());
            } else {
                System.out.println("Pilihan tidak ada.");
            }

        } else if (pilihan == 2) {
            // cetak struk dari nota yang lagi aktif
            nota.struk();

        } else if (pilihan == 3) {
            // baca nota lama berdasarkan nomor nota
            System.out.print("Nomor nota yang mau dibaca : ");
            String nomor = input.nextLine();
            nota.bacaNota(nomor);

        } else if (pilihan == 4) {
            System.out.println("Program selesai.");

        } else {
            System.out.println("Pilihan tidak ada.");
        }
    }
}