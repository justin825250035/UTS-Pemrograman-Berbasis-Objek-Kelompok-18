// class ItemNota, satu baris barang yang dibeli.
// produk bertipe Produk class induk, jadi bisa diisi
// PaperBag, Lanyard, atau KertasKado juga polymorphism
public class ItemNota {
    private Produk produk;
    private int jumlah;
    private double subTotal;

    public ItemNota(Produk produk, int jumlah) {
        this.produk = produk;
        this.jumlah = jumlah;
        hitungSubTotal();
    }

    public ItemNota() {
    }

    public Produk getProduk() {
        return produk;
    }

    public int getJumlah() {
        return jumlah;
    }

    public double getSubTotal() {
        return subTotal;
    }

    public void hitungSubTotal() {
        subTotal = produk.getHarga() * jumlah;
    }
}