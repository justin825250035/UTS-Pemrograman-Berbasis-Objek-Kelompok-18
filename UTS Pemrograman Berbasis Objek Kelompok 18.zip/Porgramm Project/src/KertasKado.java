// class KertasKado, turunan dari Produk extends
public class KertasKado extends Produk {
    private String motif;
    private String ukuran;

    public KertasKado(String namaProduk, String satuan, double harga, String motif, String ukuran) {
        super(namaProduk, satuan, harga);
        this.motif = motif;
        this.ukuran = ukuran;
    }

    public KertasKado() {
    }

    public void setMotif(String motif) {
        this.motif = motif;
    }

    public void setUkuran(String ukuran) {
        this.ukuran = ukuran;
    }

    public String getMotif() {
        return motif;
    }

    public String getUkuran() {
        return ukuran;
    }

    public String deskripsi() {
        return getNamaProduk() + " motif " + motif + ", ukuran " + ukuran;
    }
}