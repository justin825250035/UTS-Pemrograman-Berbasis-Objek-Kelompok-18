// class Lanyard, turunan dari Produk extends
public class Lanyard extends Produk {
    private String panjang;
    private String jenisClip;

    public Lanyard(String namaProduk, String satuan, double harga, String panjang, String jenisClip) {
        super(namaProduk, satuan, harga);
        this.panjang = panjang;
        this.jenisClip = jenisClip;
    }

    public Lanyard() {
    }

    public void setPanjang(String panjang) {
        this.panjang = panjang;
    }

    public void setJenisClip(String jenisClip) {
        this.jenisClip = jenisClip;
    }

    public String getPanjang() {
        return panjang;
    }

    public String getJenisClip() {
        return jenisClip;
    }

    public String deskripsi() {
        return getNamaProduk() + " panjang " + panjang + ", clip " + jenisClip;
    }
}