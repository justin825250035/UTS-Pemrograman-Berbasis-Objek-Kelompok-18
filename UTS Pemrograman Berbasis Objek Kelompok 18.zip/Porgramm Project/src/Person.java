// class Person, class induk buat Pembeli dan Toko.
// abstract karena ada method info() yang belum ada isinya
public abstract class Person {
    private String kode;
    private String nama;
    private String noHP;

    public Person(String kode, String nama) {
        this.kode = kode;
        this.nama = nama;
    }

    public Person() {
    }

    public void setKode(String kode) {
        this.kode = kode;
    }

    public void setNama(String nama) {
        this.nama = nama;
    }

    public void setNoHP(String noHP) {
        this.noHP = noHP;
    }

    public String getKode() {
        return kode;
    }

    public String getNama() {
        return nama;
    }

    public String getNoHP() {
        return noHP;
    }

    // method abstrak, wajib diisi sama Pembeli dan Toko
    public abstract String info();
}