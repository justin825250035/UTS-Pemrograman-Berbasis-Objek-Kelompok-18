// interface Cetak, nama toko dan alamat toko disimpan di sini (tetap/konstan)
public interface Cetak {
    String TOKO = "VICTORY STATIONARY";
    String ALAMAT = "Samping Proyek Pasar Pagi Lama Blok B.14 / DKS 18, Petak Baru, Jakarta Barat";

    void struk();
}