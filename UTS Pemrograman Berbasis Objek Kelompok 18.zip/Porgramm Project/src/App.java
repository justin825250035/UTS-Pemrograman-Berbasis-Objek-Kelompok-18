import java.util.Scanner;

// class App, buat jalanin semua class jadi satu program
public class App {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        // toko sudah tetap namanya (dari interface Cetak)
        Toko toko = new Toko(Cetak.TOKO, Cetak.ALAMAT, "-", "Jakarta Barat");

        // login admin dulu (lewat signIn() dari interface Login)
        toko.signIn();

        System.out.println(toko.info());
        // input data pembeli
        System.out.println();
        System.out.print("Nama Pembeli : ");
        String namaTuan = input.nextLine();
        Pembeli pembeli = new Pembeli("P001", namaTuan, toko.getNamaToko());
        System.out.println(pembeli.info());

        // input data nota
        System.out.print("No Nota      : ");
        String noNota = input.nextLine();
        System.out.print("Tanggal      : ");
        String tanggal = input.nextLine();
        Nota nota = new Nota(noNota, tanggal, pembeli, toko);

        // bikin objek Menu, dikasih nota yang baru dibuat
        Menu menu = new Menu(nota);

        // loop terus sampe user pilih keluar (menu nomor 4)
        boolean lanjut = true;
        while (lanjut) {
            menu.tampilMenu();
            int pilihan = Integer.parseInt(input.nextLine());
            menu.pilihMenu(pilihan);

            if (pilihan == 4) {
                lanjut = false;
            }
        }
    }
}